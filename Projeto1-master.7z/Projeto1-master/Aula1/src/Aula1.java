


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;


public class Aula1 {


    public static void main(String[] args) 
    {
        JFrame janela = new JFrame("Projeto Disciplina");
        JPanel painel = new JPanel();
        janela.setSize(300,200);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setVisible(true);
        janela.add(painel);
        JLabel rotulo = new JLabel();
        rotulo.setText("Nome");
        painel.add(rotulo);
        
    }
    
}
