
package aula1;

import javax.swing.JOptionPane;

public class Aula1 {


    public static void main(String[] args) 
    {
        System.out.println("Olá Mundo!!");
        JOptionPane.showMessageDialog(null, "Olá Mundo!!");
    }
    
}
